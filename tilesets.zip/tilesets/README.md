# WorkAdventure Map Starter Kit - Tilesets Folder

In this directory you should place the tileset files (PNGs) used to create your maps.
